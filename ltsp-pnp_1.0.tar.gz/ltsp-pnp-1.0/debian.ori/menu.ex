?package(ltsp-pnp):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="ltsp-pnp" command="/usr/bin/ltsp-pnp"
