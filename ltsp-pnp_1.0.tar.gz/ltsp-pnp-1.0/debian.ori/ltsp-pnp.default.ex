# Defaults for ltsp-pnp initscript
# sourced by /etc/init.d/ltsp-pnp
# installed at /etc/default/ltsp-pnp by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
